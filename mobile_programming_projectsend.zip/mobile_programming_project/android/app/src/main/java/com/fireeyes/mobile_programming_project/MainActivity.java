package com.fireeyes.mobile_programming_project;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
