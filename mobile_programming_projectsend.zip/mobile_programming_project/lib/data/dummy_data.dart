import 'package:mobile_programming_project/Models/movie.dart';

var MOVIES = [
  Movie(
  //  id: 5,
    original_title: 'Planet of the Apes',
    release_date: '02/02/2015',
    poster_path:
        'https://images-na.ssl-images-amazon.com/images/I/51fcwyusn2L._AC_.jpg',
    vote_average: 5.0,
  ),
  Movie(
   // id: 10,
    original_title: 'Shrek 2',
    release_date: '02/02/1998',
    poster_path: 'https://images-na.ssl-images-amazon.com/images/I/51%2BWoZieYBL._AC_.jpg',
    vote_average: 10.0,
  ),
  Movie(
   // id: 25,
    original_title: 'Sillicon Valley',
    release_date: '02/02/2012',
    poster_path: 'https://wallpaperaccess.com/full/1754709.jpg',
    vote_average: 5.0,
  ),
  Movie(
  //  id: 23,
    original_title: 'Inception',
    release_date: '02/02/2020',
    poster_path: 'https://images-na.ssl-images-amazon.com/images/I/912AErFSBHL._SL1500_.jpg',
    vote_average: 5.0,
  ),
  Movie(
   // id: 24,
    original_title: 'Avengers: End of Unity',
    release_date: '02/02/1934',
    poster_path: 'https://i4.hurimg.com/i/hurriyet/75/750x422/5d36ac37d3806c2300a94e62.jpg',
    vote_average: 3.0,
  ),
  Movie(
  //  id: 1,
    original_title: 'Ertugul',
    release_date: '02/02/2012',
    poster_path: 'https://cdnuploads.aa.com.tr/uploads/Contents/2018/11/06/thumbs_b_c_66b4118acfb58dbd9b4996a5790d377f.jpg?v=153328',
    vote_average: 8.9,
  ),
  Movie(
 //   id: 2,
    original_title: 'Ertugul',
    release_date: '02/02/2008',
    poster_path: 'https://cdnuploads.aa.com.tr/uploads/Contents/2018/11/06/thumbs_b_c_66b4118acfb58dbd9b4996a5790d377f.jpg?v=153328',
    vote_average: 8.9,
  ),
  Movie(
  //  id: 4,
    original_title: 'Cowboy Bebop',
    release_date: '02/02/1998',
    poster_path: 'https://images-na.ssl-images-amazon.com/images/S/sgp-catalog-images/region_US/fun-FUN-CBY-JPN_S1-Full-Image_GalleryCover-en-US-1489784785929._UR1920,1080_RI_.JPG',
    vote_average: 8.9,
  ),
  Movie(
  //  id: 5,
    original_title: 'Borat',
    release_date: '02/02/1998',
    poster_path: 'https://images-na.ssl-images-amazon.com/images/I/41nQph%2BfZ4L._AC_.jpg',
    vote_average: 7.9,
  ),
  Movie(
    //id: 12,
    original_title: 'Covid-19',
    release_date: '02/02/1998',
    poster_path: 'https://images-na.ssl-images-amazon.com/images/I/41nQph%2BfZ4L._AC_.jpg',
    vote_average: 7.9,
  ),
  Movie(
  //  id: 78,
    original_title: 'Spike Speigel',
    release_date: '02/02/1998',
    poster_path: 'https://images-na.ssl-images-amazon.com/images/I/41nQph%2BfZ4L._AC_.jpg',
    vote_average: 6.9,
  ),
];
