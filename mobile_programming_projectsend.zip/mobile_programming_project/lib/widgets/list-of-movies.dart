import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:mobile_programming_project/Models/movie.dart';
import 'package:mobile_programming_project/widgets/movie_detail.dart';
import '../data/dummy_data.dart';
import 'package:mobile_programming_project/Models/movie.dart';
import 'package:mobile_programming_project/main.dart';
import 'package:http/http.dart' as http;
class MovieList extends StatefulWidget {
  static const routeName = 'movie-list';

  final List<Movie> movies;

   MovieList({this.movies});


  @override
  _MovieListState createState() => _MovieListState(movies);

}

Widget buildCard(BuildContext ctx, int index, Function colorOption, int id, String movieName, String imageName,
    String releaseDate, double rating)

{




  var colorOfShadow = colorOption(index);
  return FlatButton(
    child: Card(
      elevation: 12,
      shadowColor: colorOfShadow,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: Colors.deepOrangeAccent,
          radius: 30,
          child: Padding(
            padding: EdgeInsets.all(8),
            child: FittedBox(
              child: Text('#${index + 1}'),
            ),
          ),
        ),
        title: Text(
          ' $movieName',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text('$releaseDate'),
        trailing: Text(
          'IMDB rating: $rating',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    ),
    onPressed: () {
      Navigator.of(ctx).pushNamed(MovieDetail.routeName, arguments: id);
    },
  );
}

class _MovieListState extends State<MovieList> {
  final List<Movie> films;
  _MovieListState(this.films);


//  List<Movie> _movies = new List<Movie>();
  @override
 /* void initState() {
    super.initState();
    _populateAllMovies();
  }

  void _populateAllMovies() async {
    final movies = await _fetchAllMovies();
    setState(() {
      _movies = movies;
    });
  }*/



  Color ranking(int index){
    switch(index) {
      case 0: {
        return Colors.yellow;
        break;
      }
      case 1: {
        return Colors.blue;
        break;
      }
      case 2:{
        return Colors.brown;
        break;
      }
      default:{
        return Colors.black54;
        break;
      }
    }
  }

  @override
  Widget build(BuildContext context) {

print("films are:"+ films.toString());
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepOrangeAccent,
        title: Center(
          child: Text('Top 120 movies'),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 0),
        child: ListView.builder(
          itemCount: films.length,
          itemBuilder: (ctx, index) {
            var movies = films[index];

            return buildCard(context, index, ranking, movies.id, movies.original_title, movies.poster_path,
                movies.release_date, movies.vote_average);
          },
        ),
      ),
    );
  }

}
