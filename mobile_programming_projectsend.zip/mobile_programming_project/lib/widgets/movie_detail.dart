import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:mobile_programming_project/Models/movie.dart';
import 'package:mobile_programming_project/data/dummy_data.dart';
import 'package:http/http.dart' as http;
class MovieDetail extends StatelessWidget {
  /*final response = await http.get(
  "https://www.freetogame.com/api/games?platform=pc");
  final result = jsonDecode(response.body);
  Iterable list = result;
  var lstcpied = result;
  var lst = new List(10);
  print("veriler aşağıda");
  print(lst);
  if (response.statusCode == 200) {
  }*/

  final List<Movie> movies;

  MovieDetail({this.movies});

  static const routeName = 'movie-detail';

  @override
  Widget build(BuildContext context) {
    print("buraya geldik mi?");
    print("movies:::"+ movies.toString());
   var movieId = ModalRoute
        .of(context)
        .settings
        .arguments as int;
    // ignore: unrelated_type_equality_checks
    var movie = movies.firstWhere((movie) => movie.id == movieId);
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
      ),
      body: Column(
        children: [
          Container(
            height: MediaQuery
                .of(context)
                .size
                .height * 0.4,
            width: double.infinity,
            child: ClipRRect(
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
              child: Image.network(
                "https://image.tmdb.org/t/p/original/"+(movie.poster_path),
                fit: BoxFit.cover,
                alignment: Alignment.center,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      movie.original_title,
                      style: TextStyle(
                        fontSize: 36,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Row(
                      children: [
                        Text(
                          movie.release_date,
                          style: TextStyle(
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Overview',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.star,
                          size: 34,
                          color: Theme
                              .of(context)
                              .primaryColor,
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          '${movie.vote_average}',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    )
                  ],
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 10),
                  width: MediaQuery
                      .of(context)
                      .size
                      .width * 0.7,
                  child: Text(
                    movie.overview,
                    textAlign: TextAlign.left,
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }


}

