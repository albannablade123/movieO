class Movie {
  int id;
  String original_title;
  double vote_average;
  String release_date;
  String poster_path;
  String overview;

  Movie({this.id, this.original_title, this.vote_average, this.release_date, this.poster_path,this.overview});

  factory Movie.fromJson(Map<String, dynamic> json) {
    return Movie(
        id: json["id"],
        poster_path: json["poster_path"],
        original_title: json["original_title"],
        release_date: json["release_date"],
        vote_average: json["vote_average"],
        overview: json["overview"]
    );
  }
}

/*
 Firg's note: 
 - Added id in the string
*/
