import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mobile_programming_project/widgets/Homepage-banner-item.dart';
import 'package:mobile_programming_project/widgets/list-of-movies.dart';
import 'package:mobile_programming_project/widgets/movie_detail.dart';
import 'package:http/http.dart' as http;
import 'Models/movie.dart';
int deger=0;
List<Movie> _movies = new List<Movie>();
void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  List<Movie> _movies = new List<Movie>();
  _MyApp createState() => _MyApp();
  }








class _MyApp extends State<MyApp> {
  void initState() {
    super.initState();
    _populateAllMovies();
  }

  void _populateAllMovies() async {
    final movies = await _fetchAllMovies();
    setState(() {
      _movies = movies;
    });
  }

  Future<List<Movie>> _fetchAllMovies() async {
  /*  print("deger kac:"+ deger.toString());

      print("başladık en başta en ");
      final response = await http.get(
          "https://api.themoviedb.org/3/movie/top_rated?api_key=f5722edf270eb4e4162ef395187fa59a&language=en-US&page=1");
    final response2 = await http.get(
        "https://api.themoviedb.org/3/movie/top_rated?api_key=f5722edf270eb4e4162ef395187fa59a&language=en-US&page=2");
     // deger++;
while(deger<2) {
  print("kaç kere");
  if (response.statusCode == 200) {
    //   print("ses ver")
    ;
    final result = jsonDecode(response.body);
    Iterable list = result['results'];
    print("aşağıya bak");
    //  print(list);
    return list.map((movie) => Movie.fromJson(movie)).toList();
    deger++;
  }
  else if (response2.statusCode == 200) {
    //   print("ses ver")
    ;
    final result = jsonDecode(response.body);
    Iterable list = result['results'];
    print("aşağıya bak");
    //  print(list);
    return list.map((movie) => Movie.fromJson(movie)).toList();
    deger++;
  }

  else {
    // print("ses ver 2")
    ;
    throw Exception("Failed to load movies!");
  }
}*/

      var responses = await Future.wait([
        http.get("https://api.themoviedb.org/3/movie/top_rated?api_key=f5722edf270eb4e4162ef395187fa59a&language=en-US&page=1"),
        http.get("https://api.themoviedb.org/3/movie/top_rated?api_key=f5722edf270eb4e4162ef395187fa59a&language=en-US&page=2"),
        http.get("https://api.themoviedb.org/3/movie/top_rated?api_key=f5722edf270eb4e4162ef395187fa59a&language=en-US&page=3"),
        http.get("https://api.themoviedb.org/3/movie/top_rated?api_key=f5722edf270eb4e4162ef395187fa59a&language=en-US&page=4"),
        http.get("https://api.themoviedb.org/3/movie/top_rated?api_key=f5722edf270eb4e4162ef395187fa59a&language=en-US&page=5"),
        http.get("https://api.themoviedb.org/3/movie/top_rated?api_key=f5722edf270eb4e4162ef395187fa59a&language=en-US&page=6"),
      ]);
      return [
        ..._getArticlesFromResponse(responses.first),
        ..._getArticlesFromResponse(responses[1]),
        ..._getArticlesFromResponse(responses[2]),
        ..._getArticlesFromResponse(responses[3]),
        ..._getArticlesFromResponse(responses[4]),
        ..._getArticlesFromResponse(responses[5]),
      ];



  }
  List<Movie> _getArticlesFromResponse(http.Response response) {
    return [
      if (response.statusCode == 200)
        for (var i in json.decode(response.body)['results'])
          Movie.fromJson(i),
    ];
  }
  @override

    // TODO: implement build
    Widget build(BuildContext context) {
      return MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          primarySwatch: Colors.orange,
          accentColor: Colors.deepOrangeAccent,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        darkTheme: ThemeData.dark(),
        home: HomeScreen(),
        routes: {
          MovieList.routeName: (ctx) => MovieList(movies: _movies),
          MovieDetail.routeName: (ctx) => MovieDetail(movies: _movies),
        },
      );
    }
  }



/*firg-note: 
- Changed topFive to MovieList
- Added MovieDetail in the routes
- Homepage-banner-item now takes 4th argument, which is the route destination
*/

class HomeScreen extends StatelessWidget {

  final List<String> list = List.generate(10, (index) => "Movie $index");


  @override
  Widget build(BuildContext context) {
    var isLandscape =
        MediaQuery.of(context).orientation == Orientation.landscape;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepOrangeAccent,
        title: Text(
          'Project ',
          textScaleFactor: 1.2,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
            icon: Icon(
              Icons.menu,
              color: Colors.white,
            ),
            onPressed: () {}),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.search,
              color: Colors.white,
            ),
            onPressed: () {
              showSearch(context: context, delegate: Search(list));
              // do something
            },
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(mainAxisAlignment: MainAxisAlignment.start, children: [
            HomepageBannerItem(
              isLandscape,
              'https://m.media-amazon.com/images/M/MV5BNzA1Njg4NzYxOV5BMl5BanBnXkFtZTgwODk5NjU3MzI@._V1_.jpg',
              'Out top 10 movie picks',
              () {
                Navigator.of(context).pushNamed(MovieList.routeName);
              },
            ),
            HomepageBannerItem(
              isLandscape,
              'https://images-na.ssl-images-amazon.com/images/I/51BANINoAxL._AC_.jpg',
              'Movie of the Month',
              () {
                Navigator.of(context)
                    .pushNamed(MovieDetail.routeName, arguments: 'm1');
              },
            ),
            HomepageBannerItem(
              isLandscape,
              'https://images-na.ssl-images-amazon.com/images/I/918B9zoR7zL._AC_SL1500_.jpg',
              'Create your own List',
              () {
                Navigator.of(context).pushNamed(MovieList.routeName);
              },
            ),
            HomepageBannerItem(
                isLandscape,
                'https://cdn11.bigcommerce.com/s-ydriczk/images/stencil/1280x1280/products/89058/93685/Joker-2019-Final-Style-steps-Poster-buy-original-movie-posters-at-starstills__62518.1572351179.jpg?c=2?imbypass=on',
                'Sort by genre',
                () {}),
          ]),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        tooltip: 'Increment',
        backgroundColor: Colors.deepOrangeAccent,
        child: Icon(Icons.add),
        onPressed: () {},
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}

class Search extends SearchDelegate {
  final List<String> listExample;

  Search(this.listExample);

  @override
  List<Widget> buildActions(BuildContext context) {
    return <Widget>[
      IconButton(
          icon: Icon(Icons.close),
          onPressed: () {
            query = "";
          })
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
        icon: Icon(Icons.arrow_back_ios),
        onPressed: () {
          Navigator.pop(context);
        });
  }

  @override
  String selectedResult;

  Widget buildResults(BuildContext context) {
    return Container(
      child: Center(
        child: Text(selectedResult),
      ),
    );
  }

  List<String> recentList = [
    "Planet of the Apes",
    "Barney The Dinosaur: zombie land"
  ];

  @override
  Widget buildSuggestions(BuildContext context) {
    List<String> suggestionList = [];
    query.isEmpty
        ? suggestionList = recentList
        : suggestionList.addAll(listExample.where(
            (element) => element.contains(query),
          ));

    return ListView.builder(
      itemCount: suggestionList.length,
      itemBuilder: (context, index) {
        return ListTile(
          title: Text(
            suggestionList[index],
          ),
        );
      },
    );
  }
}
